package VO;

import java.util.ArrayList;

import org.json.JSONArray;

public class Recommendation {
	String user;
	JSONArray recommendation;
	
	Recommendation(String user) {
		this.user = user;
		this.recommendation = new JSONArray();
	}
	
	Recommendation(String user, ArrayList<String> recommendation) {
		this.user = user;
		
		this.recommendation = new JSONArray();
		for(int i=0; i<recommendation.size(); i++) {
			this.recommendation.put(recommendation.get(i));
		}
	}
	
	void addRecommendation(String recommendation) {
		this.recommendation.put(recommendation);
	}
}
