package VO;

import java.util.ArrayList;
import java.util.HashSet;

import org.json.JSONArray;
import org.json.JSONException;

public class User2 {
	String user;
	ArrayList<String> phone;
	ArrayList<String> following;

	public User2(String user) {
		this.user = user;
		phone = new ArrayList<>();
		following = new ArrayList<>();
	}

	public User2(String user, JSONArray phone, JSONArray following) {
		this.user = user;

		try {
			this.phone = new ArrayList<>();
			for (int i = 0; i < phone.length(); i++) {
				this.phone.add(phone.getString(i));
			}

			this.following = new ArrayList<>();
			for (int i = 0; i < following.length(); i++) {
				this.following.add(following.getString(i));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void resetPhone() {
		phone = new ArrayList<>();
	}

	public void resetFollowing() {
		following = new ArrayList<>();
	}

	public void addPhoneUser(String phone) {
		this.phone.add(phone);
	}

	public void addFollowing(String following) {
		this.following.add(following);
	}
}
