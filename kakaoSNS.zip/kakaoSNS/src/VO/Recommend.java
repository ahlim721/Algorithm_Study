package VO;

public class Recommend {

	String userID;
	String recommendID;
	int percentage;
	
	public Recommend(String userID, String recommendID, int percentage) {
		this.userID = userID;
		this.recommendID = recommendID;
		this.percentage = percentage;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getRecommendID() {
		return recommendID;
	}

	public void setRecommendID(String recommendID) {
		this.recommendID = recommendID;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	
	
}
