package VO;

import java.util.HashSet;

import org.json.JSONArray;
import org.json.JSONException;

public class User {
	String user;
	HashSet<String> phone;
	HashSet<String> following;
	HashSet<String> follower;

	public User(String user) {
		this.user = user;
		phone = new HashSet<>();
		following = new HashSet<>();
		follower = new HashSet<>();
	}

	public User(String user, JSONArray phone, JSONArray following) {
		this.user = user;

		try {
			this.phone = new HashSet<>();
			for (int i = 0; i < phone.length(); i++) {
				this.phone.add(phone.getString(i));
			}

			this.following = new HashSet<>();
			for (int i = 0; i < following.length(); i++) {
				this.following.add(following.getString(i));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		follower = new HashSet<>();
	}

	public HashSet<String> getFollower() {
		return follower;
	}

	public void addFollower(String id) {
		this.follower.add(id);
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public HashSet<String> getPhone() {
		return phone;
	}

	public HashSet<String> getFollowing() {
		return following;
	}

	public void resetPhone() {
		phone = new HashSet<>();
	}

	public void resetFollowing() {
		following = new HashSet<>();
	}

	public void addPhoneUser(String phone) {
		this.phone.add(phone);
	}

	public void addFollowing(String following) {
		this.following.add(following);
	}
}
