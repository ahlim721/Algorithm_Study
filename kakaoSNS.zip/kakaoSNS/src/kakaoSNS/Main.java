package kakaoSNS;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

import org.json.JSONObject;

import VO.Recommend;
import VO.User;

public class Main {
	
	private static void doRecommendSystem() {
		
		// 토큰 받아오기.
		// api.start()
		String token = Connection.start();
		System.out.println(token);
		
		int day = 0;
		
		system : 
		while(true) {
			if(day > 500)
				break;
			// get users
			JSONObject getUsers = Connection.users(1, 100, token);
			HashMap<String, User> users = API.getUsers(getUsers, "users");
			
			// get new users
			JSONObject getNewUsers = Connection.newUsers(token);
			HashMap<String, User> newUsers = API.getUsers(getNewUsers, "new_users");
			
			users = API.appendUsers(users, newUsers);
						
			API.makeFollowers(users);
			
			ArrayList<User> followerList = new ArrayList<>();
			for(User u : users.values()) {
				followerList.add(u);
			}
			followerList.sort(new Comparator<User>() {
				@Override
				public int compare(User o1, User o2) {
					return o2.getFollower().size() - o1.getFollower().size();
				}
			});
			
			// make list for recommend
			ArrayList<Recommend> recommendList = API.recommend(users, followerList);
			recommendList.sort(new Comparator<Recommend>() {
				@Override
				public int compare(Recommend o1, Recommend o2) {
					return o2.getPercentage() - o1.getPercentage();
				}
			});
			
			JSONObject postRecommend = API.makeJSONObject(API.makeJSONArray(recommendList, users.size()));
			boolean canRecommend = Connection.recommend(postRecommend, token);
			
			if(!canRecommend) {
				System.out.println("오류!");
				break;
			} 
			
			else {
				Connection.runSimulation(token);
				
				while(true) {
					String status = Connection.status(token);
					
					if(status.equals("working")) {
						continue;
					} else if(status.equals("done")) {
						break;
					} else if(status.equals("finish")) {
						break system;
					}
				}
			}
				
			System.out.println(day++);
		}
		
		
	}

	public static void main(String[] args) {
		doRecommendSystem();
	}

}
