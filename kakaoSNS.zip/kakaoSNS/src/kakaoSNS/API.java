package kakaoSNS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import VO.Recommend;
import VO.User;

public class API {
	
	public static HashMap<String, User> getUsers(JSONObject users, String key) {
		
		HashMap<String, User> map = new HashMap<>();
		
		try {
			JSONArray userList = users.getJSONArray(key);
			
			for(int i=0; i<userList.length(); i++) {
				JSONObject user = userList.getJSONObject(i);
				
				String uid = user.getString("user");
				
				JSONArray phone = new JSONArray();
				if(user.has("phone"))
					phone = user.getJSONArray("phone");

				JSONArray following = new JSONArray();
				if(user.has("following"))
					following = user.getJSONArray("following");

				map.put(uid, new User(uid, following, phone));
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return map;
	}

	public static HashMap<String, User> appendUsers(HashMap<String, User> users, HashMap<String, User> newUsers) {
		
		for(String key : newUsers.keySet()) {
			users.put(key, newUsers.get(key));
		}
		
		return users;
	}

	public static ArrayList<Recommend> recommend(HashMap<String, User> users, ArrayList<User> followerList) {
		
		ArrayList<Recommend> recommendList = new ArrayList<>();
		
		for(String key : users.keySet()) {
			
			User getInfo = users.get(key);
			
			String id = getInfo.getUser();
			HashSet<String> phoneSet = getInfo.getPhone();
			HashSet<String> followingSet = getInfo.getFollowing();
			
			// 팔로잉하지 않은 사람들 중 내 전화번호에 있는 지 확인.
			phoneSet.removeAll(followingSet);
			
			// 내 전화번호에 있는 사람들은 다 팔로잉 한 상태.
			if(phoneSet.isEmpty()) {
				// 전화번호에 없는 사람들 중, 추천.
				
				// 팔로잉하지 않은 사람들 중 팔로워 수가 가장 많은 사람을 추천.
				for(User u : followerList) {
					if(!followingSet.contains(u.getUser())) {
						recommendList.add(new Recommend(id, u.getUser(), getPercentage(users, 5, getInfo.getPhone(), followingSet, u.getUser())));
						break;
					}
				}
			}
			
			// 해당 사람들을 기준으로 추천.
			else {
				for(String following : phoneSet) {
					int percentage = getPercentage(users, 30, getInfo.getPhone(), followingSet, following);
					recommendList.add(new Recommend(id, following, percentage));
				}
			}
			
		}
		
		return recommendList;
		
	}

	private static int getPercentage(HashMap<String, User> users, int init, HashSet<String> phoneSet, HashSet<String> followingSet, String following) {
		int percentage = init;
		
		for(String p : phoneSet) {
			if(percentage >= 100)
				return percentage;
			
			if(users.get(p).getFollowing().contains(following))
				init += 10;
		}
		
		for(String f : followingSet) {
			if(percentage >= 100)
				return percentage;
			
			if(users.get(f) != null && users.get(f).getFollowing() != null && users.get(f).getFollowing().contains(following))
				init += 10;
		}
		
		return percentage;
	}

	public static void makeFollowers(HashMap<String, User> users) {
		
		for(String key : users.keySet()) {
			HashSet<String> followingSet = users.get(key).getFollowing();
			for(String f : followingSet) {
				if(users.containsKey(f))
					users.get(f).addFollower(key);
			}
		}
		
	}
	
	public static HashMap<String, JSONArray> makeJSONArray(ArrayList<Recommend> recommendList, int size) {
		
		HashMap<String, JSONArray> map = new HashMap<>();
		
		int idx = 0;
		for(Recommend r : recommendList) {
			if(map.containsKey(r.getUserID())) {
				JSONArray jsary = map.get(r.getUserID());
				if(jsary.length() < 10) {
					jsary.put(r.getRecommendID());
					idx++;
				}
			} 
			else {
				JSONArray jsary = new JSONArray();
				jsary.put(r.getRecommendID());
				map.put(r.getUserID(), jsary);
				idx++;
			}
			
			if(idx >= size)
				break;
		}
		
		return map;
	}

	public static JSONObject makeJSONObject(HashMap<String, JSONArray> recommendMap) {
		
		JSONArray recommendations = new JSONArray();
		
		for(String key : recommendMap.keySet()) {
			
			JSONObject recommendation = new JSONObject();
			
			try {
				recommendation.put("user", key);
				recommendation.put("recommendation", recommendMap.get(key));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			recommendations.put(recommendation);
		}
		
		JSONObject result = new JSONObject();
		
		try {
			result.put("recommendations", recommendations);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}


	
}
