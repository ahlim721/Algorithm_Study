package kakaoSNS;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class Connection {

	static String url = "https://wqwfrkh5k1.execute-api.ap-northeast-2.amazonaws.com/kakao-2020/";
	static String xAuthToken = "7e8578c86fec71d3260083b650868bf4";
	static String type = "application/json";

	public static String start() {

		System.out.println(">>>> connection start <<<<");

		HttpURLConnection conn = null;
		JSONObject responseJson = null;
		String response = null;

		String startURL = url + "start";

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("X-Auth-Token", xAuthToken);
			conn.setRequestProperty("Content-Type", type);

			JSONObject problem = new JSONObject();
			problem.put("problem", 1);
			
			conn.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(problem.toString());
			wr.flush();

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = "";
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}

				responseJson = new JSONObject(sb.toString());
				response = responseJson.getString("token");
			} else {
				response = String.valueOf(responseCode);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	public static JSONObject users(int page, int size, String token) {

		System.out.println(">>>> connection users <<<<");

		HttpURLConnection conn = null;
		JSONObject response = null;

		String startURL = url + "users?page=" + page + "&size=" + size;

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", token);

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = "";
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}

				response = new JSONObject(sb.toString());
			} else {
				System.out.println(conn.getResponseMessage());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;

	}

	public static JSONObject newUsers(String token) {
		System.out.println(">>>> connection new users <<<<");

		HttpURLConnection conn = null;
		JSONObject response = null;

		String startURL = url + "new_users";

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", token);

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = "";
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}

				response = new JSONObject(sb.toString());
			} else {
				System.out.println(conn.getResponseMessage());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;

	}

	public static boolean recommend(JSONObject postRecommend, String token) {
		System.out.println(">>>> connection recommend <<<<");

		HttpURLConnection conn = null;

		String startURL = url + "recommend";

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Authorization", token);
			conn.setRequestProperty("Content-Type", type);

			conn.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(postRecommend.toString());
			wr.flush();

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				System.out.println(conn.getResponseMessage());
			} else {
				System.out.println(conn.getResponseMessage());
				return false;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	public static void runSimulation(String token) {
		System.out.println(">>>> connection run simulation <<<<");

		HttpURLConnection conn = null;

		String startURL = url + "run_simulation";

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("PUT");
			conn.setRequestProperty("Authorization", token);

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				System.out.println(conn.getResponseMessage());
			} else {
				System.out.println(conn.getResponseMessage());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String status(String token) {
		System.out.println(">>>> connection check status <<<<");

		HttpURLConnection conn = null;
		JSONObject responseJson = null;
		String response = null;

		String startURL = url + "status";

		try {
			URL url = new URL(startURL);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", token);

			int responseCode = conn.getResponseCode();
			if (responseCode == 200) { // 성공
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = "";
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}

				responseJson = new JSONObject(sb.toString());
				response = responseJson.getString("status");
			} else {
				System.out.println(conn.getResponseMessage());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return response;
	}

}
